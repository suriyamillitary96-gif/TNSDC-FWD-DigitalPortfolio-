function showTime() {
  const now = new Date();
  let h = now.getHours();
  let m = now.getMinutes();
  let s = now.getSeconds();

  // Add zero if number < 10
  h = h < 10 ? "0" + h : h;
  m = m < 10 ? "0" + m : m;
  s = s < 10 ? "0" + s : s;

  document.getElementById("time").textContent = `${h}:${m}:${s}`;
}

// Update every second
setInterval(showTime, 1000);

// Call immediately so it doesn’t wait 1 second
showTime();